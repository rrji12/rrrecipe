// app.js

const searchBtn = document.getElementById("search-btn");
const searchInput = document.getElementById("search-input");
const loadingIndicator = document.getElementById("loading");
const recipesContainer = document.getElementById("recipes");

const apiUrl = "https://www.themealdb.com/api/json/v1/1/filter.php?i=";

// Function to handle the search
searchBtn.addEventListener("click", () => {
    const query = searchInput.value.trim();
    if (query === "") {
        alert("Please enter a search term.");
        return;
    }
    
    // Show loading indicator
    loadingIndicator.style.display = "block";
    
    // Fetch recipes
    fetchRecipes(query);
});

// Function to fetch recipes from TheMealDB API
async function fetchRecipes(query) {
    try {
        const response = await fetch(apiUrl + query);
        const data = await response.json();
        
        // Hide loading indicator
        loadingIndicator.style.display = "none";
        
        if (data.meals) {
            displayRecipes(data.meals);
        } else {
            recipesContainer.innerHTML = "<p>No recipes found.</p>";
        }
    } catch (error) {
        // Handle errors gracefully
        loadingIndicator.style.display = "none";
        recipesContainer.innerHTML = "<p>Error fetching data. Please try again later.</p>";
    }
}

// Function to display the recipes on the page
function displayRecipes(meals) {
    recipesContainer.innerHTML = ""; // Clear previous results
    meals.forEach(meal => {
        const recipeCard = document.createElement("div");
        recipeCard.classList.add("recipe-card");

        recipeCard.innerHTML = `
            <img src="${meal.strMealThumb}" alt="${meal.strMeal}">
            <h3>${meal.strMeal}</h3>
            <p>Click below for the full recipe.</p>
            <a href="https://www.themealdb.com/meal/${meal.idMeal}" target="_blank">View Recipe</a>
        `;
        
        recipesContainer.appendChild(recipeCard);
    });
}
